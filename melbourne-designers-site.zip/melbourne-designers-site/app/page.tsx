import { Hero } from "@/components/Hero";
import { StickyNav } from "@/components/StickyNav";
import { ParallaxShowcase } from "@/components/ParallaxShowcase";
import { SearchStrip } from "@/components/SearchStrip";
import { FeaturedDesigners } from "@/components/FeaturedDesigners";
import { HowItWorks } from "@/components/HowItWorks";
import { LeadCaptureCTA } from "@/components/LeadCaptureCTA";
import { Testimonials } from "@/components/Testimonials";
import { PhaseThree } from "@/components/PhaseThree";
import { Footer } from "@/components/Footer";

export default function Page() {
  return (
    <main>
      <StickyNav />
      <Hero />
      <ParallaxShowcase />
      <SearchStrip />
      <FeaturedDesigners />
      <HowItWorks />
      <LeadCaptureCTA />
      <Testimonials />
      <PhaseThree />
      <Footer />
    </main>
  );
}
