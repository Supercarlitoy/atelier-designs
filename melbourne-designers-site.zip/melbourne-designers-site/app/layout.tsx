import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Melbourne Designers Directory",
  description:
    "Discover independent Melbourne creatives across branding, digital, interiors, and experiential design in one curated directory.",
  icons: {
    icon: "/favicon.ico"
  },
  openGraph: {
    title: "Melbourne Designers",
    description:
      "A curated guide to the designers shaping Melbourne's visual identity across disciplines.",
    url: "https://melbourne.design",
    siteName: "Melbourne Designers",
    locale: "en_AU",
    type: "website"
  }
};

export default function RootLayout({
  children
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="bg-brand text-white">
        <div className="min-h-screen flex flex-col">
          {children}
        </div>
      </body>
    </html>
  );
}
