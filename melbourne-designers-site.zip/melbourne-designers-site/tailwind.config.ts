import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./lib/**/*.{js,ts,jsx,tsx,mdx}"
  ],
  theme: {
    extend: {
      fontFamily: {
        display: ["'Playfair Display'", "serif"],
        body: ["'Inter'", "sans-serif"]
      },
      colors: {
        brand: {
          DEFAULT: "#0B0D0F",
          accent: "#F6B756",
          muted: "#292D33"
        }
      },
      spacing: {
        18: "4.5rem"
      },
      boxShadow: {
        floating: "0 24px 48px rgba(9, 12, 20, 0.18)"
      }
    }
  },
  plugins: []
};

export default config;
