# Scripts

Use this folder for automation helpers (eg. seeding Supabase, syncing Cloudinary assets, running analytics checks). None required for the initial skeleton.
