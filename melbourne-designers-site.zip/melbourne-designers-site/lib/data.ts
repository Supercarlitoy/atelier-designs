export type Designer = {
  name: string;
  discipline: string;
  bio: string;
  website: string;
};

export const featuredDesigners: Designer[] = [
  {
    name: "Studio Kilda",
    discipline: "Brand & Digital",
    bio: "Boutique studio blending coastal minimalism with tactile print craft.",
    website: "https://studiokilda.com"
  },
  {
    name: "Northside Form",
    discipline: "Interior Design",
    bio: "Hospitality-led interiors with a soft brutalist sensibility.",
    website: "https://northsideform.studio"
  },
  {
    name: "Lumen Assembly",
    discipline: "Spatial & Experiential",
    bio: "Designers of immersive cultural activations across Melbourne's creative precincts.",
    website: "https://lumenassembly.xyz"
  }
];

export const navigation = [
  { id: "featured", label: "Featured" },
  { id: "how-it-works", label: "How it works" },
  { id: "cta", label: "Join" },
  { id: "testimonials", label: "Testimonials" },
  { id: "phase-three", label: "Phase 3" }
];

export const testimonials = [
  {
    quote:
      "We doubled qualified enquiries within a month of listing on the directory.",
    name: "Maya Lee",
    role: "Founder, Form & Fold"
  },
  {
    quote: "The lead capture CTA integrates cleanly into our existing systems.",
    name: "André Silva",
    role: "Director, Atelier South"
  }
];

export const phaseThreeBlocks = [
  {
    title: "Community Events",
    description:
      "Quarterly salons spotlighting Melbourne's emergent creative neighbourhoods."
  },
  {
    title: "Creator Playbooks",
    description:
      "Downloadable templates covering pricing, proposals, and client onboarding."
  },
  {
    title: "Partner Perks",
    description:
      "Exclusive supplier and venue discounts negotiated for directory members."
  }
];
