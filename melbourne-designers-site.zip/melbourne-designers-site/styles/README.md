# Styles directory

Reserved for future CSS modules or design token exports (if design system evolves beyond Tailwind). Tailwind handles current styling needs via `app/globals.css`.
