export function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="section-shell pb-16 text-xs uppercase tracking-[0.3rem] text-white/40">
      © {year} Melbourne Designers Directory · Crafted for the creative capital.
    </footer>
  );
}
