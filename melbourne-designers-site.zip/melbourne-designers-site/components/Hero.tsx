import { motion } from "framer-motion";

export function Hero() {
  return (
    <section
      id="hero"
      className="relative isolate overflow-hidden bg-[radial-gradient(circle_at_top,#1B2027,transparent_60%)]"
    >
      <div className="section-shell py-32 sm:py-40">
        <div className="max-w-3xl space-y-8">
          <motion.h1
            className="font-display text-4xl leading-[1.1] sm:text-6xl"
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            Melbourne&rsquo;s independent designers, curated in one directory.
          </motion.h1>
          <motion.p
            className="text-lg text-white/80 sm:text-xl"
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ delay: 0.1, duration: 0.6 }}
          >
            Find studios and solo practitioners across branding, digital, interior, spatial and experiential design. Built with Vide-Infra inspired hero visuals and intentional storytelling.
          </motion.p>
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
            <a
              href="#search"
              className="rounded-full bg-brand-accent px-6 py-3 text-sm font-semibold uppercase text-brand"
            >
              Explore directory
            </a>
            <a href="#cta" className="text-sm uppercase tracking-[0.3rem] text-white/70">
              Claim your profile →
            </a>
          </div>
        </div>
      </div>
      <motion.div
        className="pointer-events-none absolute inset-0 -z-10"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1.2 }}
      >
        <div className="absolute right-10 top-10 h-60 w-60 rounded-full bg-brand-accent/10 blur-3xl" />
        <div className="absolute bottom-0 left-1/4 h-40 w-40 rounded-full bg-brand-accent/20 blur-3xl" />
      </motion.div>
    </section>
  );
}
