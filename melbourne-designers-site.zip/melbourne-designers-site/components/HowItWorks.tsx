const steps = [
  {
    title: "Claim your profile",
    description:
      "Submit your studio details, showcase projects, and highlight disciplines. Optional Supabase integration ready for profile storage.",
    cta: "Start claim process"
  },
  {
    title: "Get verified",
    description:
      "Our editorial team reviews every submission to maintain Melbourne's design calibre standards.",
    cta: "What we check"
  },
  {
    title: "Connect with leads",
    description:
      "Qualified enquiries land in your inbox, CMS, or CRM with onboarding sequences ready to customise.",
    cta: "See lead flow"
  }
];

export function HowItWorks() {
  return (
    <section id="how-it-works" className="section-shell py-24">
      <div className="mb-12 max-w-2xl space-y-4">
        <p className="text-xs uppercase tracking-[0.3rem] text-white/50">How it works</p>
        <h2 className="font-display text-3xl sm:text-4xl">Simple pathways to get discovered and convert work.</h2>
        <p className="text-white/70">
          Built to capture interest from emerging founders, hospitality operators, cultural organisations, and developer clients seeking fresh design talent.
        </p>
      </div>
      <div className="grid gap-8 md:grid-cols-3">
        {steps.map((step) => (
          <article key={step.title} className="flex flex-col justify-between rounded-3xl border border-white/10 bg-white/5 p-6">
            <div className="space-y-4">
              <h3 className="font-display text-2xl">{step.title}</h3>
              <p className="text-sm text-white/70">{step.description}</p>
            </div>
            <a href="#cta" className="mt-6 text-sm text-brand-accent">
              {step.cta} →
            </a>
          </article>
        ))}
      </div>
    </section>
  );
}
