export function SearchStrip() {
  return (
    <section
      id="search"
      className="border-y border-white/10 bg-black/60 py-8 backdrop-blur sticky-nav-offset"
    >
      <div className="section-shell flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
        <div>
          <p className="text-xs uppercase tracking-[0.3rem] text-white/50">Search the directory</p>
          <h2 className="font-display text-2xl">Filter by discipline, neighbourhood, availability.</h2>
        </div>
        <form className="flex w-full max-w-xl flex-col gap-4 md:flex-row">
          <input
            type="search"
            placeholder="Try &ldquo;brand identity&rdquo; or &ldquo;Collingwood&rdquo;"
            className="w-full rounded-full border border-white/10 bg-white/5 px-5 py-3 text-sm text-white placeholder:text-white/40 focus:outline-none"
          />
          <button
            type="submit"
            className="rounded-full bg-brand-accent px-5 py-3 text-sm font-semibold uppercase text-brand"
          >
            Search
          </button>
        </form>
      </div>
    </section>
  );
}
