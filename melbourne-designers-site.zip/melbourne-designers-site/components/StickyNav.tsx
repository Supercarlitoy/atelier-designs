"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { navigation } from "@/lib/data";

export function StickyNav() {
  const [isSolid, setIsSolid] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsSolid(window.scrollY > 32);
    };

    handleScroll();
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div
      className={`sticky top-0 z-50 border-b border-white/10 backdrop-blur transition-colors ${
        isSolid ? "bg-brand/90" : "bg-brand/50"
      }`}
    >
      <div className="section-shell flex items-center justify-between py-4">
        <Link href="#hero" className="font-display text-2xl tracking-tight">
          Melbourne Designers
        </Link>
        <nav className="hidden gap-6 text-sm uppercase tracking-[0.2rem] md:flex">
          {navigation.map((item) => (
            <a key={item.id} href={`#${item.id}`} className="hover:text-brand-accent">
              {item.label}
            </a>
          ))}
        </nav>
        <a
          className="rounded-full border border-white/20 px-4 py-1 text-xs uppercase tracking-[0.3rem]"
          href="#cta"
        >
          Join waitlist
        </a>
      </div>
    </div>
  );
}
