import { testimonials } from "@/lib/data";

export function Testimonials() {
  return (
    <section id="testimonials" className="section-shell py-24">
      <div className="mb-12 max-w-2xl space-y-4">
        <p className="text-xs uppercase tracking-[0.3rem] text-white/50">Testimonials</p>
        <h2 className="font-display text-3xl sm:text-4xl">Early partners validating the model.</h2>
      </div>
      <div className="grid gap-8 md:grid-cols-2">
        {testimonials.map((item) => (
          <blockquote
            key={item.name}
            className="rounded-3xl border border-white/10 bg-white/5 p-8 text-white/80"
          >
            <p className="text-lg">“{item.quote}”</p>
            <footer className="mt-6 text-sm uppercase tracking-[0.3rem] text-white/50">
              {item.name} · {item.role}
            </footer>
          </blockquote>
        ))}
      </div>
    </section>
  );
}
