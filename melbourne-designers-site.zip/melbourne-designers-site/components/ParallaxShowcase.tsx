"use client";

import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";

export function ParallaxShowcase() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const translateYSlow = useTransform(scrollYProgress, [0, 1], [0, -120]);
  const translateYFast = useTransform(scrollYProgress, [0, 1], [0, -200]);

  return (
    <section ref={ref} className="relative overflow-hidden py-24">
      <div className="section-shell pointer-events-none relative hidden h-[420px] md:block">
        <motion.div
          style={{ y: translateYSlow }}
          className="absolute left-12 top-10 h-60 w-44 rounded-[40px] border border-white/10 bg-gradient-to-b from-white/20 to-white/5"
        />
        <motion.div
          style={{ y: translateYFast }}
          className="absolute right-12 top-0 h-80 w-56 rounded-[48px] border border-white/10 bg-gradient-to-b from-brand-accent/30 to-brand-accent/0"
        />
        <motion.div
          style={{ y: translateYSlow }}
          className="absolute left-1/2 top-24 h-72 w-72 -translate-x-1/2 rounded-full border border-white/20 bg-brand-accent/10 blur-3xl"
        />
      </div>
      <div className="section-shell md:hidden">
        <div className="rounded-3xl border border-white/10 bg-white/5 p-8 text-sm text-white/60">
          Parallax hero assets render on larger breakpoints. Replace with production imagery when assets land.
        </div>
      </div>
    </section>
  );
}
