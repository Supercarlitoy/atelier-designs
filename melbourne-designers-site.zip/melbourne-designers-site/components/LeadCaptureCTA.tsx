export function LeadCaptureCTA() {
  return (
    <section
      id="cta"
      className="section-shell mb-24 rounded-3xl border border-brand-accent/40 bg-brand-accent/10 px-8 py-16 text-brand"
    >
      <p className="text-xs uppercase tracking-[0.3rem] text-brand/70">Join the waitlist</p>
      <h2 className="font-display text-3xl text-brand md:text-4xl">
        Secure your launch spot in the Melbourne Designers directory.
      </h2>
      <p className="mt-4 max-w-xl text-brand/80">
        Collect leads via Airtable, Supabase, or your CRM. Hook up the form action to your provider of choice—placeholder endpoint included for rapid integration.
      </p>
      <form className="mt-8 grid gap-4 md:grid-cols-[2fr_2fr_1fr]">
        <input
          type="text"
          name="name"
          placeholder="Your name"
          className="rounded-full border border-brand/20 bg-white/90 px-5 py-3 text-sm text-brand placeholder:text-brand/50 focus:outline-none"
        />
        <input
          type="email"
          name="email"
          placeholder="Studio email"
          className="rounded-full border border-brand/20 bg-white/90 px-5 py-3 text-sm text-brand placeholder:text-brand/50 focus:outline-none"
        />
        <button
          type="submit"
          className="rounded-full bg-brand px-5 py-3 text-sm font-semibold uppercase tracking-[0.2rem] text-brand-accent"
        >
          Notify me
        </button>
      </form>
      <p className="mt-4 text-xs uppercase tracking-[0.3rem] text-brand/60">
        Phase 1 launch · Limited to 50 profiles
      </p>
    </section>
  );
}
