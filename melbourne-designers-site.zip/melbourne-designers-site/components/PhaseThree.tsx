import { phaseThreeBlocks } from "@/lib/data";

export function PhaseThree() {
  return (
    <section id="phase-three" className="section-shell pb-32">
      <div className="mb-12 max-w-2xl space-y-4">
        <p className="text-xs uppercase tracking-[0.3rem] text-white/50">Phase 3 roadmap</p>
        <h2 className="font-display text-3xl sm:text-4xl">Momentum features arriving post-launch.</h2>
        <p className="text-white/70">
          This scaffold outlines future modules so engineering can plan integrations with Supabase, Cloudinary, and analytics tooling.
        </p>
      </div>
      <div className="grid gap-8 md:grid-cols-3">
        {phaseThreeBlocks.map((block) => (
          <article key={block.title} className="rounded-3xl border border-white/10 bg-white/5 p-6">
            <h3 className="font-display text-2xl">{block.title}</h3>
            <p className="mt-4 text-sm text-white/70">{block.description}</p>
          </article>
        ))}
      </div>
    </section>
  );
}
