import { featuredDesigners } from "@/lib/data";

export function FeaturedDesigners() {
  return (
    <section id="featured" className="section-shell py-24">
      <div className="mb-12 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-xs uppercase tracking-[0.3rem] text-white/50">Featured designers</p>
          <h2 className="font-display text-3xl sm:text-4xl">Curated studios making waves now.</h2>
        </div>
        <a href="#cta" className="text-sm uppercase tracking-[0.3rem] text-brand-accent">
          Claim your spot →
        </a>
      </div>
      <div className="grid gap-8 md:grid-cols-3">
        {featuredDesigners.map((designer) => (
          <article key={designer.name} className="space-y-4 rounded-3xl border border-white/10 bg-white/5 p-6 shadow-floating">
            <header className="space-y-1">
              <h3 className="font-display text-2xl">{designer.name}</h3>
              <p className="text-sm uppercase tracking-[0.3rem] text-brand-accent/90">
                {designer.discipline}
              </p>
            </header>
            <p className="text-sm text-white/80">{designer.bio}</p>
            <a href={designer.website} className="text-sm text-brand-accent" target="_blank" rel="noreferrer">
              View profile
            </a>
          </article>
        ))}
      </div>
    </section>
  );
}
