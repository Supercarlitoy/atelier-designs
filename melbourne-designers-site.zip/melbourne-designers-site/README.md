# Melbourne Designers Directory

Production-ready skeleton for a Next.js App Router site showcasing Melbourne's independent designers. The scaffold includes Tailwind CSS for styling, Framer Motion for motion design, and TypeScript-first patterns ready for API and Supabase integrations.

## Tech stack
- Next.js 14 (App Router, TypeScript)
- React 18
- Tailwind CSS + PostCSS
- Framer Motion
- ESLint (Next.js core web vitals ruleset)

## Getting started
1. Install dependencies with `pnpm install` (or `npm install`).
2. Run `pnpm dev` to start the development server at `http://localhost:3000`.
3. Update components in `app/` and `components/` with real data, integrate Supabase, Cloudinary, and analytics as needed.

## Structure highlights
- `app/page.tsx` wires the hero, search strip, sticky navigation, featured designers, how-it-works, lead capture CTA, testimonials, and Phase 3 roadmap blocks.
- `components/` contains modular React components ready for enhancement.
- `lib/data.ts` centralises placeholder content for easy replacement.
- Tailwind configuration includes base brand theming and typography tokens aligned with the design direction.

## Next steps
- Connect Supabase or alternative backends for designer profiles and lead capture flows.
- Replace placeholder copy, imagery, and data with production content.
- Add analytics scripts (PostHog or GA4) in `app/layout.tsx` when ready.
- Configure deployment target (Vercel recommended) once integrations are wired.
