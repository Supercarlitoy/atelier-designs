# Public assets

Drop static assets (logos, OG images, favicons) here once received from design. Placeholder kept to ensure directory is tracked.
