# Build & Run Instructions

## What this is
Production-ready skeleton for the Melbourne designers directory. Matches the locked Canvas spec: Vide-Infra hero, black search strip, sticky nav, parallax, featured designers, how-it-works with claim/signup mention, lead capture CTA, testimonials scaffold, and Phase 3 blocks.

## Prereqs
- Frameworks: Next.js (App Router) + React 18 + TypeScript + TailwindCSS + Framer Motion
- Tooling: Node 20+, pnpm or npm, Git, VS Code
- Services: Vercel (deploy), Supabase (DB/auth/storage) [optional for profiles], Cloudinary (media) [optional], PostHog/GA4 (analytics) [optional]
- Design assets: Figma file and design tokens (typography, colours, spacing), brand logo, OG template

## Setup
1. Install dependencies
   ```bash
   pnpm install
   # or
   npm install
   ```
2. Run the development server
   ```bash
   pnpm dev
   # or
   npm run dev
   ```
3. Open [http://localhost:3000](http://localhost:3000) in your browser.

## Deployment
- Recommended: push to a GitHub repo and connect to Vercel.
- Configure environment variables for Supabase, Cloudinary, analytics, and CRM endpoints when integrations are ready.
- Optional preview: `pnpm build && pnpm start` will run the production server locally.

## Notes for engineers
- All sections are intentionally stubbed with placeholder copy and structure to accelerate wiring data sources.
- `lib/data.ts` holds sample data. Replace with live calls (Supabase, CMS, local JSON) as needed.
- Form actions are placeholders—connect to Airtable, HubSpot, Supabase, or preferred service.
- Tailwind theme tokens reflect the Vide-Infra-inspired palette; adjust once final design tokens are confirmed.
- Components are isolated and typed to simplify motion/animation layering and eventual content chunking for CMS.
